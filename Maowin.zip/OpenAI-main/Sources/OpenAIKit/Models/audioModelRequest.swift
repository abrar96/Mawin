//
//  audioModel.swift
//  OpenAIKit
//
//  Created by Abrar ibrahim on 16/03/2023.
//

import Foundation

public struct audioModelRequest: Codable {
    public var file: URL? = nil
    public let model: String
}


public struct audioModelResponse: Codable {
        public let text: String
}


////
////  audioModel.swift
////  OpenAIKit
////
////  Created by Abrar ibrahim on 16/03/2023.
////
//
//import Foundation
//
//public struct audioModelRequestFirst: Codable {
//    var data: [audioModelRequest]
//}
//
//public struct audioModelRequest: Codable {
//    public let file: [audioFileModelRequest]
//    public let model: [audioModelModelRequest]
//}
//
//public struct audioFileModelRequest: Codable {
//    public let key: String
//    public let src: String
//    public let type: String
//}
//
//public struct audioModelModelRequest: Codable {
//    public let key: String
//    public let model: String
//    public let type: String
//}
//
//public struct audioModelResponse: Codable {
//        public let text: String
//}
