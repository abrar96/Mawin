//
//  HomeViewController.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 15/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import UIKit
import OpenAIKit

class HomeViewController: UIViewController {

    
    @IBOutlet weak var quotesLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        sendQuestion()
        let nibcell = UINib(nibName: "featuresCollectionViewCell", bundle: nil)
        collectionView.register(nibcell, forCellWithReuseIdentifier: "featuresCollectionViewCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .none
    }

}


extension HomeViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  6
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // calculation of cell size
        return CGSizeMake(collectionView.frame.size.width/3 - 10, collectionView.frame.size.width/3)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "featuresCollectionViewCell", for: indexPath) as! featuresCollectionViewCell
        cell.labelName.text = "Apply for new apartment"
        cell.layer.cornerRadius = 3
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

    }
}

extension HomeViewController {
    // Send Question
    @IBAction private func sendQuestion() {
       
        quotesLabel.text = " "
        let arrayPrompt = ["quote of the day", "اقتباس اليوم"]
        let prompt = arrayPrompt.randomElement() ?? ""
        let previousMessages: [AIMessage] = []
        
        openAI.sendChatCompletion(newMessage: AIMessage(role: .user, content: prompt), previousMessages: previousMessages, model: .gptV3_5(.gptTurbo), maxTokens: 2048, n: 1, completion: { [weak self] result in

            
            switch result {
            case .success(let aiResult):
                DispatchQueue.main.async { [weak self] in
                    if let text = aiResult.choices.first?.message?.content {
                        // Received Result
                        self?.quotesLabel.text = text
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async { [weak self] in
                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default))
                    self?.present(alert, animated: true)
                }
            }
        })
        
    }
}
