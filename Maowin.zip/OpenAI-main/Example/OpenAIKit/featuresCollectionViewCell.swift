//
//  featuresCollectionViewCell.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 15/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import UIKit

class featuresCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var iconImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
