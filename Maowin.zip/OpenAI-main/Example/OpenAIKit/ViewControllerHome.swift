//
//  ViewControllerHome.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 17/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import UIKit
import OpenAIKit

class ViewControllerHome: UIViewController {

    @IBOutlet weak var quotesLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        quotes()
    }

    func quotes() {
        quotesLabel.text = " "
        let arrayPrompt = ["quote of the day", "اقتباس اليوم"]
        let prompt = arrayPrompt.randomElement() ?? ""
        let previousMessages: [AIMessage] = []
        
        openAI.sendChatCompletion(newMessage: AIMessage(role: .user, content: prompt), previousMessages: previousMessages, model: .gptV3_5(.gptTurbo), maxTokens: 2048, n: 1, completion: { [weak self] result in
            
            switch result {
            case .success(let aiResult):
                DispatchQueue.main.async { [weak self] in
                    if let text = aiResult.choices.first?.message?.content {
                        self?.quotesLabel.text = text
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async { [weak self] in
                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default))
                    self?.present(alert, animated: true)
                }
            }
        })
    }
    
}
