//
//  ChooseViewController.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 18/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import UIKit

class ChooseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
