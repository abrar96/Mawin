//
//  whisperAPI.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 17/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import Foundation
