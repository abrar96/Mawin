//
//  AudioViewController.swift
//  AudioTranscribe
//
//  Created by Haya Al-Sulaiman on 15/03/2023.
//

import UIKit
import AVFoundation
import OpenAIKit
import OpenAIAPI
import Alamofire

class AudioViewController: UIViewController {
    var recorder: AVAudioRecorder?
    var url:URL?
    var RecordPath: String?
    var fileURL: URL = URL(fileURLWithPath: "")
    var data = Data()
    //let openAI = OpenAIAPI(OpenAIAPIConfig(secret: "..."))
    //var ActualPath: String?
    
    @IBOutlet weak var StopRecording: UIButton!
    @IBOutlet weak var StartRecording: UIButton!
    @IBOutlet weak var PauseRecording: UIButton!
    @IBOutlet weak var viewText: UITextView!
    
    
    
    @IBAction func StartRecording(_ sender: Any) {
        //player?.stop()
        //self.playPauseBtn.setTitle("Play", for: .normal)
        if let recorder = self.recorder{
            if recorder.isRecording{
                self.recorder?.pause()
                StartRecording.setTitle("Restart Recording ...", for: .normal)
            }
            else{
                StartRecording.setTitle("Pause Recording ...", for: .normal)
                self.recorder?.record()
            }
        }
        else{
            StopRecording.isEnabled = true //enables stopRecording button
            StartRecording.setTitle("Pause Recording ...", for: .normal)
            initializeRecorder()
        }
    }
    
    @IBAction func StopRecording(_ sender: Any) {
        StopRecording.isEnabled = false
        StartRecording.setTitle("Start Recording", for: .normal)
        PauseRecording.isHidden = false
        self.recorder?.stop()
        let session = AVAudioSession.sharedInstance()
        try! session.setActive(false)
        self.url = self.recorder?.url
        RecordPath = self.url?.relativeString
        self.recorder = nil
        
        
        let filename = "/Users/abraribrahim/Desktop/Abrar.m4a"
        
        let fileHandle: FileHandle? = FileHandle(forReadingAtPath: filename)
        fileHandle?.seek(toFileOffset: 2880) //skip past the headers
        
        let dataLenToRead = 1391 * 1039 * 2
        if #available(iOS 13.4, *) {
            do {
                data = try fileHandle?.readToEnd() ?? Data()
            } catch {
                
            }
            
        } else {
            // Fallback on earlier versions
        }
            //    translateAudio()
    }
    
    @IBAction func PauseRecording(_ sender: Any) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StopRecording.isEnabled = false
        PauseRecording.isHidden = true
        
    }
    
    func CallWhisperAPI(){
        
        
    }
    func initializeRecorder() {
        
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, options: .defaultToSpeaker)
        let directory =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        var recordSetting = [AnyHashable: Any]()
        recordSetting[AVFormatIDKey] = kAudioFormatMPEG4AAC
        recordSetting[AVSampleRateKey] = 16000.0
        recordSetting[AVNumberOfChannelsKey] = 1
        if let filePath = directory.first?.appendingPathComponent("MyAudioMemo.m4a"), let audioRecorder = try? AVAudioRecorder(url: filePath, settings: (recordSetting as? [String : Any] ?? [:])){
            print(filePath)
            RecordPath = filePath.relativeString
            
            
            
            self.recorder = audioRecorder
            self.recorder?.delegate = self
            self.recorder?.isMeteringEnabled = true
            self.recorder?.prepareToRecord()
            self.recorder?.record()
        }
        //filepath is an optional URL
        
        func w() async {
            var multipart = MultipartRequest()
            for field in [
                "firstName": "John",
                "lastName": "Doe"
            ] {
                multipart.add(key: field.key, value: field.value)
            }

            multipart.add(
                key: "file",
                fileName: "Abrar.m4a",
                fileMimeType: "image/png",
                fileData: "fake-image-data".data(using: .utf8)!
            )

            /// Create a regular HTTP URL request & use multipart components
            let url = URL(string: "https://httpbin.org/post")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue(multipart.httpContentTypeHeadeValue, forHTTPHeaderField: "Content-Type")
            request.httpBody = multipart.httpBody

            /// Fire the request using URL sesson or anything else...
            do {
                let (data, response) = try await URLSession.shared.data(for: request)
                print((response as! HTTPURLResponse).statusCode)
                print(String(data: data, encoding: .utf8)!)
            } catch {
                
            }
        }
        
    }
}
extension AudioViewController: AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    
}
//
//extension AudioViewController {
//    // Send Audio
//    @IBAction private func translateAudio() {
//
//        let AudioParmsdata = OpenAIAPIAudioParms(file: data, model: "", response_format: "", temperature: 0)
//
//        openAI2.createTranscription(filedata: data, filename: "Abrar.m4a", config: AudioParmsdata, completion: { [weak self] result in
//            switch result {
//            case .success(let aiResult):
//                DispatchQueue.main.async { [weak self] in
//                    print(aiResult.text)
//                }
//
//            case .failure(let error):
//                DispatchQueue.main.async { [weak self] in
//                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
//                    alert.addAction(UIAlertAction(title: "Ok", style: .default))
//                    self?.present(alert, animated: true)
//                }
//            }
//        })
        
        
        //        openAI.sendaudioRequest(file: data, model: "whisper-1", completion: { [weak self] result in
        //
        //            switch result {
        //            case .success(let aiResult):
        //                DispatchQueue.main.async { [weak self] in
        //                    print(aiResult.text)
        //                }
        //
        //            case .failure(let error):
        //                DispatchQueue.main.async { [weak self] in
        //                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
        //                    alert.addAction(UIAlertAction(title: "Ok", style: .default))
        //                    self?.present(alert, animated: true)
        //                }
        //            }
        //        })
//    }
//}




// Alamofire

extension AudioViewController {

}

public extension Data {

    mutating func append(
        _ string: String,
        encoding: String.Encoding = .utf8
    ) {
        guard let data = string.data(using: encoding) else {
            return
        }
        append(data)
    }
}

public struct MultipartRequest {
    
    public let boundary: String
    
    private let separator: String = "\r\n"
    private var data: Data

    public init(boundary: String = UUID().uuidString) {
        self.boundary = boundary
        self.data = .init()
    }
    
    private mutating func appendBoundarySeparator() {
        data.append("--\(boundary)\(separator)")
    }
    
    private mutating func appendSeparator() {
        data.append(separator)
    }

    private func disposition(_ key: String) -> String {
        "Content-Disposition: form-data; name=\"\(key)\""
    }

    public mutating func add(
        key: String,
        value: String
    ) {
        appendBoundarySeparator()
        data.append(disposition(key) + separator)
        appendSeparator()
        data.append(value + separator)
    }

    public mutating func add(
        key: String,
        fileName: String,
        fileMimeType: String,
        fileData: Data
    ) {
        appendBoundarySeparator()
        data.append(disposition(key) + "; filename=\"\(fileName)\"" + separator)
        data.append("Content-Type: \(fileMimeType)" + separator + separator)
        data.append(fileData)
        appendSeparator()
    }

    public var httpContentTypeHeadeValue: String {
        "multipart/form-data; boundary=\(boundary)"
    }

    public var httpBody: Data {
        var bodyData = data
        bodyData.append("--\(boundary)--")
        return bodyData
    }
}


