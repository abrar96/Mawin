//
//  EmailViewController.swift
//  OpenAIKit_Example
//
//  Created by Abrar ibrahim on 14/03/2023.
//  Copyright © 2023 Futurra Group. All rights reserved.
//

import UIKit
import OpenAIKit

class EmailViewController: UIViewController {

    @IBOutlet weak var textViewEmail: UITextView!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var emailText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func ConvertEmailAction(_ sender: Any) {
        sendQuestion()
    }
}

extension EmailViewController {
    // Send Question
    @IBAction private func sendQuestion() {
        textViewEmail.text = " "
        
        let prompt = "Correct this to standard English:\n\n\(textFieldEmail.text ?? "")"

      //  let previousMessages: [AIMessage] = []
        
        openAI.sendCompletion(prompt: prompt, model: .gptV3_5(.davinciText003), maxTokens: 2048, completion: { [weak self] result in
//            DispatchQueue.main.async { self?.stopLoading() }
            
            switch result {
            case .success(let aiResult):
                DispatchQueue.main.async { [weak self] in
                    if let text = aiResult.choices.first?.text {
                        // Received Result
                        self?.textViewEmail.text = text
                    }
                }
                
            case .failure(let error):
                DispatchQueue.main.async { [weak self] in
                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default))
                    self?.present(alert, animated: true)
                }
            }
        })
    }
}
